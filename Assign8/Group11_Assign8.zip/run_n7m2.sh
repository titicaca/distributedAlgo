teachnetpath=$(head -1 teachnet.path)
java -jar $teachnetpath --cp . --config n7m2_config.txt --compile

