import java.awt.Color;

import teachnet.simulator.Message;
import teachnet.view.renderer.Shape;

/**
 * Group 11
 * Yuwen Chen,    352038
 * Fangzhou Yang, 352040
 * Xugang Zhou,   352032
 * 
 * Implementation of oral messages for Byzantine Generals
 */
public class OralMessage extends Message {
	
	public String path;
	public int value;
	
	public int m;
	public boolean[] G;
	
	public int majority;
	
	Color[] colors = {Color.GREEN, Color.RED, Color.PINK, Color.ORANGE};
	
	public static final String values[] = {"a", "b", "c", "d"};
	
	public static final int defaultValue = 4;
	
	public Color color = Color.GREEN;
	Shape shape = Shape.CIRCLE;
	
	public OralMessage(int m, boolean[] G, int v, String path) {
		this.m = m;
		this.G = G;
		this.value = v;
		this.path = path;
		
		this.color = colors[value % 4];
	}
	
	public void setValue(int v) {
		this.value = v;
		this.color = colors[value % 4];
	}
	
	
	public String toString() {
		return path + "->" + values[value];
	}

}
