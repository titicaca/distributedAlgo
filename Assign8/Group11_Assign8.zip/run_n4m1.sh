teachnetpath=$(head -1 teachnet.path)
java -jar $teachnetpath --cp . --config n4m1_config.txt --compile

