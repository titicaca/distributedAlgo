import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import teachnet.algorithm.BasicAlgorithm;

/**
 * Group 11
 * Yuwen Chen,    352038
 * Fangzhou Yang, 352040
 * Xugang Zhou,   352032
 * 
 * Implementation of a Byzantine Generals Algorithm
 */

public class ByzantineGenerals extends BasicAlgorithm {
	
	
	public static final Color Commander_COLOR = Color.BLUE;
	public static final Color Lieutenant_COLOR = Color.GREEN;
	public static final Color Traitor_COLOR = Color.RED;
	
	int id;
	int n,m;
	int pendingMsg;
	
	int value;
	
	Color color = null;
	String caption;
	int markInterface = -1;
	
	boolean isCommander = false;
	boolean isTraitor = false;
	
//	int[] itfMaps;
	
	ArrayList<OralMessage> tree = new ArrayList<OralMessage>();
	
	public void setup(java.util.Map<String, Object> config)
	{
		id = (Integer) config.get("node.id");
		n = (Integer) config.get("n");
		m = (Integer) config.get("m");
		pendingMsg = n-1-m;
		
		color = Lieutenant_COLOR;
		caption = "" + id;
		
		if(id == 0) {
			isCommander = true;
			color = Commander_COLOR;
			caption = "Commander "+id;
		}
		
		String tmp = (String) config.get("traitors");
		String[] traitors = tmp.split(",");
		for(int i=0; i<traitors.length; ++i) {
			if(Integer.parseInt(traitors[i]) == id) {
				isTraitor = true;
				color = Traitor_COLOR;
				break;
			}
		}
	}

	@Override
	public void initiate() {
		if(this.isCommander) {
			boolean[] G = new boolean[n];
			G[this.id] = false;
			for(int i=1; i<n; ++i) {
				G[i] = true;
			}
			
			if(this.isTraitor) {
				Random random = new Random();
				int numFaulty = random.nextInt(n-2*m-1)+1;
				ArrayList<Integer> victims = new ArrayList<Integer>();
				for(int i=0; i<numFaulty; ++i) {
					int vi;
					do {
						vi = random.nextInt(n-1)+1;
					}while(victims.contains(vi));
					victims.add(vi);
				}
				
				for(int i=1; i<n; ++i) {
					if(victims.contains(i)) {
						send(i, new OralMessage(this.m, G, 1, ""+this.id));
					}
					else {
						send(i, new OralMessage(this.m, G, 0, ""+this.id));
					}
				}
			}
			else {
				for(int i=1; i<n; ++i) {
					send(i, new OralMessage(this.m, G, 0, ""+this.id));
				}
			}
		}

	}

	@Override
	public void receive(int interf, Object arg1) {
		OralMessage msg = (OralMessage)arg1;
		
		tree.add(msg);
		
		if(msg.m != 0) {
			boolean[] newG = Arrays.copyOf(msg.G, msg.G.length);
			newG[this.id] = false;
			
			OralMessage newMsg = new OralMessage(msg.m-1, newG, msg.value, ""+this.id+":"+msg.path);
			
			//traitor generate faulty message
			if(this.isTraitor) {
				if(msg.path.length() == 1) {
					newMsg.setValue((msg.value + 1)%4);
				}
			}
			
			for(int i=0; i<newG.length; ++i) {
				if(newG[i]) {
					send(i, newMsg);
				}
			}
		}
		else {
			this.pendingMsg--;

			if(this.pendingMsg == 0) {
				
				int maj = this.treeMajority();
				this.caption = this.caption + "(Majority "+maj+")";

				
			}
		}
		

	}
	
	private int treeMajority() {
		
		for(int i=0; i<tree.size(); ++i) {
			tree.get(i).majority = tree.get(i).value;
		}
		
		for(int h=m; h>0; --h) {
			for(int i=0; i<tree.size(); ++i) {
				if(tree.get(i).path.length() == (2*h-1)) {
					int[] cnt = new int[4];
					cnt[0] = 0;
					cnt[1] = 0;
					cnt[2] = 0;
					cnt[3] = 0;
					
					cnt[tree.get(i).majority%4]++;
					for(int k=0; k<tree.size(); ++k) {
						if( (tree.get(k).path.length() == 2*h+1) && tree.get(k).path.contains(tree.get(i).path)){
							cnt[tree.get(k).majority%4]++;
						}
					}
					
					int max = cnt[0];
					for(int a=1; a<4; ++a) {
						if(cnt[a]>max)
							max = cnt[a];
					}
					for(int a=0; a<4; ++a) {
						if(cnt[a] == max) {
							tree.get(i).majority = a;
							for(int b=a+1; b<4; ++b) {
								if(cnt[b] == max) {
									tree.get(i).majority = OralMessage.defaultValue;
								}
							}
							break;
						}
					}
				}
			}
		}
		
		for(int i=0; i<tree.size(); ++i) {
			if(tree.get(i).path.length() == 1) {
				return tree.get(i).majority;
			}
		}
		
		return 0;
	}

}
